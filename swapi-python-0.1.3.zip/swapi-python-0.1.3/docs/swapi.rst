swapi package
=============

Submodules
----------

swapi.exceptions module
-----------------------

.. automodule:: swapi.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

swapi.models module
-------------------

.. automodule:: swapi.models
    :members:
    :undoc-members:
    :show-inheritance:

swapi.settings module
---------------------

.. automodule:: swapi.settings
    :members:
    :undoc-members:
    :show-inheritance:

swapi.swapi module
------------------

.. automodule:: swapi.swapi
    :members:
    :undoc-members:
    :show-inheritance:

swapi.utils module
------------------

.. automodule:: swapi.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: swapi
    :members:
    :undoc-members:
    :show-inheritance:
