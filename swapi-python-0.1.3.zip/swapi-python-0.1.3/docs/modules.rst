swapi
=====

.. toctree::
   :maxdepth: 4

   swapi
