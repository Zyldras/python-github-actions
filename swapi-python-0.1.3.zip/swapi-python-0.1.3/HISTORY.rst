.. :changelog:

History
-------

0.1.0 (2014-12-21)
---------------------

* First release on PyPI.


0.1.2 (2014-12-22)
------------------

* Python 3.3 and Python 3.4 compatability


0.1.3 (2014-12-22)
-------------------

* Add "swapi-python" to User-Agent to help with analytics
