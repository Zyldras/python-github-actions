# -*- coding: utf-8 -*-


class ResourceDoesNotExist(Exception):
    pass
